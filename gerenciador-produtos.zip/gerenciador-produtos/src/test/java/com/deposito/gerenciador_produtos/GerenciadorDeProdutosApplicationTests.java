package com.deposito.gerenciador_produtos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorDeProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
