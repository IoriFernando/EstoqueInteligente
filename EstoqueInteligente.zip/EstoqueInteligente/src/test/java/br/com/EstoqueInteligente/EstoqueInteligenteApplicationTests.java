package br.com.EstoqueInteligente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueInteligenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
